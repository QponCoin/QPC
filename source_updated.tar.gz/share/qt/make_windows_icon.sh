#!/bin/bash
# create multiresolution windows icon
ICON_DST=../../src/qt/res/icons/qpon.ico

convert ../../src/qt/res/icons/qponcoin-16.png ../../src/qt/res/icons/qpon-32.png ../../src/qt/res/icons/qpon-48.png ${ICON_DST}
